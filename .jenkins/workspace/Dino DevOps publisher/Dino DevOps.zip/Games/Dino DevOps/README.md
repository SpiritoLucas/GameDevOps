# Introduction
https://mp.weixin.qq.com/s/PnvcSBe0Va3GVIodGIjYRg

# Environment
```
OS: Windows10
Python: Python3.5+(have installed necessary dependencies)
```

# Usage
```
Step1:
pip install -r requirements.txt
Step2:
run "python Game7.py"
```

# Game Display
![giphy](demonstration/running.gif)